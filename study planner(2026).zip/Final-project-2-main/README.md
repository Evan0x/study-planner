# Study Planner Website

Responsive Study Planner built with **HTML/CSS/JavaScript** and a Node/Express backend.

## Latest improvements

### ✅ Stability / data persistence
- Fixed the "Profile → Home then refresh = data gone" issue.
- Homework and activities are now stored in `localStorage` and re-render automatically.
- Profile fields are persisted in `localStorage`.

### ✅ Authentication
- Local auth uses **bcrypt** password hashing.
- Added optional **Google OAuth** authentication with Passport.

### ✅ UI/UX refresh
- Cleaner dashboard layout with responsive sidebar + cards.
- Better visual hierarchy for actions (Add / Save / Delete).
- Improved login/signup pages with inline validation and clearer states.
- Responsive styling across Home / Profile / About pages.

---

## Run locally

> Run these commands in the **same folder as `server.js`**.

1. Install dependencies
```bash
npm install
```

2. Create env file
```bash
cp .env.example .env
```
Fill values in `.env`.

3. Make sure MongoDB is running
- local: `mongodb://127.0.0.1:27017/myDatabase`
- or set `MONGODB_URI` to MongoDB Atlas

4. Start app
```bash
npm start
```

5. Open in browser
- `http://localhost:3000/loginPage.html`

---

## Google OAuth (optional)
Set in `.env`:
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_CALLBACK_URL` (default: `http://localhost:3000/auth/google/callback`)

