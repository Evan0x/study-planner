
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import session from 'express-session';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json());
app.use(cors({
  origin: process.env.CORS_ORIGIN || true,
  credentials: true
}));

// Sessions (required for Passport)
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev_secret_change_me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax'
  }
}));

app.use(passport.initialize());
app.use(passport.session());

// ----- DB -----
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/myDatabase";
mongoose.connect(MONGODB_URI).then(()=>{
  console.log('Connected to the db');
}).catch(err => {
  console.error('MongoDB connection error:', err);
});

// ----- Models -----
const userSchema = new mongoose.Schema({
  username: { type: String, unique: true, sparse: true },
  passwordHash: { type: String }, // for local accounts
  googleId: { type: String, unique: true, sparse: true }, // for Google accounts
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model("User", userSchema);

// ----- Passport serialization -----
passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id);
    done(null, user || false);
  } catch (e) {
    done(e);
  }
});

// ----- Google OAuth -----
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL || 'http://localhost:3000/auth/google/callback'
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      const googleId = profile.id;
      let user = await User.findOne({ googleId });
      if (!user) {
        user = await User.create({ googleId });
      }
      return done(null, user);
    } catch (e) {
      return done(e);
    }
  }));
} else {
  console.warn('Google OAuth not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to enable.');
}

// ----- Helpers -----
function requireAuth(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  return res.status(401).json({ message: 'Not authenticated' });
}

// ----- Routes -----
// Local login (username + password)
app.post('/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ message: 'Missing username or password' });

  const user = await User.findOne({ username });
  if (!user || !user.passwordHash) return res.status(401).json({ message: 'Invalid login' });

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ message: 'Invalid login' });

  req.login(user, (err) => {
    if (err) return res.status(500).json({ message: 'Login failed' });
    return res.json({ message: 'Login success' });
  });
});

// Check username exists (for signup)
app.post('/check-username', async (req, res) => {
  const username = req.body?.username;
  if (!username) return res.status(400).json({ exists: false });

  const user = await User.findOne({ username });
  return res.json({ exists: !!user });
});

// Register (hash password with bcrypt)
app.post('/register', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ message: 'Missing username or password' });

  const existing = await User.findOne({ username });
  if (existing) return res.status(400).json({ message: 'Username already used' });

  const saltRounds = Number(process.env.BCRYPT_ROUNDS || 10);
  const passwordHash = await bcrypt.hash(password, saltRounds);

  await User.create({ username, passwordHash });
  return res.json({ message: 'Account created' });
});

// Logout
app.post('/logout', (req, res) => {
  req.logout?.(() => {
    res.json({ message: 'Logged out' });
  });
});

// Current session user
app.get('/me', requireAuth, (req, res) => {
  res.json({ id: req.user.id, username: req.user.username || null, googleId: req.user.googleId || null });
});

// Google auth endpoints
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/loginPage.html' }),
  (req, res) => {
    // After Google login, go to home page (front-end)
    res.redirect('/home.html');
  }
);

// Serve static frontend for convenience (optional but helpful)
app.use(express.static(process.env.STATIC_DIR || './'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is listening at port ${PORT}`);
});
